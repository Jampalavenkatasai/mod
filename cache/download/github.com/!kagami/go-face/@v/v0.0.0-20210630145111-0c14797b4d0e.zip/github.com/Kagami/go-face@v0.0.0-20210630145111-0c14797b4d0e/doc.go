/*
Package face implements face recognition for Go using dlib, a popular
machine learning toolkit.
*/
package face
